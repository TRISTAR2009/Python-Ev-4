import flet as ft
from flet import Container, Page, Stack

def main(page: ft.Page):
    page.title = "Go: 5 stones in row"
    page.scroll = "ALWAYS"

    # Define board dimensions
    board_size = 15
    cell_size = 40
    board_width = (board_size - 1) * cell_size
    board_height = (board_size - 1) * cell_size

    # Create a stack for absolute positioning
    stack = Stack()

    # Draw brown background rectangle in the stack
    stack.controls.append(Container(
        width=board_width + 40,
        height=board_height + 40,
        bgcolor=ft.Colors.BROWN,
    ))

    # Initialize the board state
    board_state = [[None for _ in range(board_size)] for _ in range(board_size)]

    # Draw horizontal and vertical lines and labels using Containers
    for i in range(board_size):
        # Horizontal line
        stack.controls.append(Container(
            width=board_width,
            height=2,  # Line thickness
            bgcolor=ft.Colors.BLACK,
            top=20 + i * cell_size,
            left=20,
        ))

        # Vertical line
        stack.controls.append(Container(
            width=2,  # Line thickness
            height=board_height,
            bgcolor=ft.Colors.BLACK,
            top=20,
            left=20 + i * cell_size,
        ))

        # Label horizontal lines with numbers (1-13)
        if i < board_size:
            stack.controls.append(Container(
                content=ft.Text(str(i + 1), color=ft.Colors.BLACK),
                left=5, 
                top=20 + i * cell_size - 10,
                width=30, 
                height=20
            ))
        
        # Label vertical lines with letters (A-M)
        stack.controls.append(Container(
            content=ft.Text(chr(65 + i), color=ft.Colors.BLACK),  # A is ASCII 65
            left=20 + i * cell_size - 10, 
            top=5,
            width=30, 
            height=20
        ))

    stones = []  # List to keep track of placed stones

    def place_stone(x, y, color):
        # Create a new stone at the clicked location
        stone = Container(
            width=30,
            height=30,
            bgcolor=color,
            border_radius=15,
            alignment=ft.alignment.center,
            left=x - 15,  # Center the stone on the drop target
            top=y - 15,   # Center the stone on the drop target
        )

        stones.append(stone)  # Keep track of placed stones
        stack.controls.append(stone)  # Add the new stone to the stack
        
        page.update()

    def check_winner(row: int, col: int, color: ft.Colors):
        directions = [
            (1, 0),   # Horizontal
            (0, 1),   # Vertical
            (1, 1),   # Diagonal \
            (1, -1)   # Diagonal /
        ]

        for dr, dc in directions:
            count = 1
            
            # Check in one direction
            r, c = row + dr, col + dc
            while 0 <= r < board_size and 0 <= c < board_size and board_state[r][c] == color:
                count += 1
                r += dr
                c += dc
            
            # Check in the opposite direction
            r, c = row - dr, col - dc
            while 0 <= r < board_size and 0 <= c < board_size and board_state[r][c] == color:
                count += 1
                r -= dr
                c -= dc
            
            if count >= 5:  
                return True
        
        return False

    def add_stone(color_input: str, color: ft.Colors):
        if len(color_input) >= 2:
            column_char = color_input[0].upper()  # First character for column (A-M)
            row_str = color_input[1:]              # Remaining characters for row

            column = ord(column_char) - ord('A')   # Convert letter to index (A -> 0)
            
            try:
                row = int(row_str) - 1               # Convert number string to index (1 -> 0)
                if row_str.startswith('0'):           # Check for invalid leading zeroes
                    return

                if (0 <= column < board_size and 
                    0 <= row < board_size and 
                    board_state[row][column] is None):  # Check if the position is empty
                    
                    place_stone(20 + column * cell_size, 
                                 20 + row * cell_size, color)
                    
                    # Update the board state with the new stone color
                    board_state[row][column] = color
                    
                    if check_winner(row, column, color):
                        print(f"{'White' if color == ft.Colors.WHITE else 'Black'} wins!")
                        page.add(ft.Text(f"{'White' if color == ft.Colors.WHITE else 'Black'} wins!", size=24))
                        page.update()
                    
            except ValueError:
                pass  # Ignore invalid row inputs

    def on_add_white(e):
        add_stone(white_input.value, ft.Colors.WHITE)
        white_input.value = ""  # Clear the input field after submission

    def on_add_black(e):
        add_stone(black_input.value, ft.Colors.BLACK)
        black_input.value = ""  # Clear the input field after submission

    white_input = ft.TextField(label="White Stone Coordinate (e.g., A1)", on_submit=lambda e: on_add_white(e))
    black_input = ft.TextField(label="Black Stone Coordinate (e.g., A1)", on_submit=lambda e: on_add_black(e))

    page.add(white_input)
    page.add(black_input)

    page.add(stack)  # Add stack to the page

# Run the app
ft.app(target=main)