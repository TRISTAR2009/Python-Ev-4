import flet as ft

Make_Username = ft.TextField(label="Set Username", max_length=20)
Make_Password = ft.TextField(label="Set Password", password=True, can_reveal_password=True, max_length=20)

def set_credentials(page: ft.Page):
    def save_credentials(e):
        with open("Username_and_Password.txt", "w") as file:
            file.write(f"{Make_Username.value}\n")
            file.write(f"{Make_Password.value}\n")
            page.add(ft.Text("Username and Password saved"))
        
    save_button = ft.ElevatedButton("Save", on_click=save_credentials)
    page.add(Make_Username)
    page.add(Make_Password)
    page.add(save_button)

def login_user(page: ft.Page):
    username_field = ft.TextField(label="Enter Username", max_length=20)
    password_field = ft.TextField(label="Enter Password", password=True, can_reveal_password=True, max_length=20)

    def validate_credentials(e):
        entered_username = username_field.value
        entered_password = password_field.value
        valid = False

        with open("Username_and_Password.txt", "r") as file:
            stored_username = file.readline().strip() 
            stored_password = file.readline().strip()
                
            if stored_username == entered_username and stored_password == entered_password:
                valid = True

        if valid:
            page.add(ft.Text("Login successful!"))
        else:
            page.add(ft.Text("Invalid username or password."))

        username_field.value = ""
        password_field.value = ""
        page.update()

    login_button = ft.ElevatedButton("Login", on_click=validate_credentials)
    page.add(username_field)
    page.add(password_field)
    page.add(login_button)


#Extra points part
def sign_in_new_user(page: ft.Page):
    New_username_field = ft.TextField(label="Enter new Username", max_length=20)
    New_password_field = ft.TextField(label="Enter new Password", password=True, can_reveal_password=True, max_length=20)

    def validate_new_credentials(e):
        new_username = New_username_field.value
        new_password = New_password_field.value
        username_exists = False

        with open("Username_and_Password.txt", "r") as file:
            stored_username = file.readline().strip() 
            stored_password = file.readline().strip()
            
            if stored_username == new_username:
                username_exists = True

        if not username_exists:
            with open("Username_and_Password.txt", "a") as file:  
                file.write(f"{new_username}\n")
                file.write(f"{new_password}\n")
            page.add(ft.Text("New account sign in successful!"))
        else:
            page.add(ft.Text("Username already used"))

        New_username_field.value = ""
        New_password_field.value = ""
        page.update()

    Sign_in_button = ft.ElevatedButton("Sign in", on_click=validate_new_credentials)
    page.add(New_username_field)
    page.add(New_password_field)
    page.add(Sign_in_button)

def main(page: ft.Page):
    set_credentials(page)  
    login_user(page)
    sign_in_new_user(page)      

ft.app(target=main)