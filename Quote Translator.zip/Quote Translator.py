import flet as ft

def main(page: ft.Page):
    translations = {
        "en": "I am inevitable",
        "kr": "난 필연적인 존재다다",
        "es": "Soy inevitable",
        "ht": "Mwen se inevitab"
    }

    image = ft.Image(
        src="Screenshot 2025-04-04 093724.png",
        width=150,
        height=200,
        fit=ft.ImageFit.COVER,
        border_radius=10
    )

    quote_text = ft.Text(
        value=translations["en"],
        size=18,
        selectable=True,
        text_align=ft.TextAlign.CENTER,
        weight=ft.FontWeight.W_500
    )

    def change_language(e):
        quote_text.value = translations[e.control.value]
        page.update()

    language_selector = ft.RadioGroup(
        content=ft.Column([
            ft.Radio(value="en", label="English (Original)"),
            ft.Radio(value="kr", label="Korean"),
            ft.Radio(value="es", label="Spanish"),
            ft.Radio(value="ht", label="Haitian Creole")
        ]),
        on_change=change_language,
        value="en"
    )

    page.add(
        ft.Column([
            ft.Text("Thanos Quote", size=24, weight=ft.FontWeight.BOLD),
            image,
            quote_text,
            ft.Text("Select Language:", size=16),
            language_selector
        ],
        spacing=20,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    )

ft.app(target=main)
